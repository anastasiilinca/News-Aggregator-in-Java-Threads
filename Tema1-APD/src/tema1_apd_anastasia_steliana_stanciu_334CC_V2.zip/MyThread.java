import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.BrokenBarrierException;

import static java.lang.Math.pow;
import static java.util.Collections.min;

public class MyThread extends Thread{
    int id;
    int start;
    int end;

    public MyThread(int id) {
        this.id =  id;
    }

    public void run() {
        /* TASK4 - Duplicate Removal */
        duplicateRemoval(id);

        try {
            Tema1.barrier.await();
        } catch(BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }
        /* TASK2 - Category Classification */
        categoryClassification(id);
        /* TASK3 - Language Classification */
        languageClassification(id);
        /* TASK5 - Interest Words */
        interestWords(id);

        try {
            Tema1.barrier.await();
        } catch(BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        /* Do some undone writing. */
        if (Tema1.NR_OF_THREADS == 1) {
            writeKeywordsCount();
            writeAllArticles();
        } else {
            if (id == 0) {
                writeAllArticles();
            }
            if (id == 1) {
                writeKeywordsCount();
            }
        }
        /* TASK6 - Reports */
        /* Make sure all threads are at this point of execution before doing reports. */
        try {
            Tema1.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        bestAuthor(id);

        if (id == 0) {
            topLanguage();
            topCategory();
        }

        if (id == 0) {
            topEnglishWord();
        }

        mostRecentArticle(id);

        writeAll(id);

        if (id == 0) {
            writeReports();
        }
    }

    public void writeAll(int id) {

    }

    public void duplicateRemoval(int id) {
        /* Compute indexes. */
        int start = id * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS);
        int end = Math.min(Tema1.articles.size(), (id + 1) * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS));

        /* Iterate through assigned articles. */
        for (int i = start; i < end; i++) {
            Article article = Tema1.articles.get(i);

            Tema1.partialArticleByTitle.get(id).merge(article.title, 1, Integer::sum);
            Tema1.partialArticleByUuid.get(id).merge(article.uuid, 1, Integer::sum);
        }

        /* Wait for all threads to finish partial work. */
        try {
            Tema1.barrier.await();
        } catch(BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        /* Only thread 0 merges partial results into global results. */
        if (id == 0) {
            for (int i = 0; i < Tema1.NR_OF_THREADS; i++) {
                for (Map.Entry<String, Integer> entry : Tema1.partialArticleByTitle.get(i).entrySet()) {
                    Tema1.articleFreqByTitle.merge(entry.getKey(), entry.getValue(), Integer::sum);
                }

                for (Map.Entry<String, Integer> entry : Tema1.partialArticleByUuid.get(i).entrySet()) {
                    Tema1.articleFreqByUuid.merge(entry.getKey(), entry.getValue(), Integer::sum);
                }
            }

            /* Remove duplicates. */
            for (Map.Entry<String, Integer> entry : Tema1.articleFreqByTitle.entrySet()) {
                if (entry.getValue() > 1) {
                    Tema1.articles.removeIf(element -> element.title.equals(entry.getKey()));
                }
            }

            for (Map.Entry<String, Integer> entry : Tema1.articleFreqByUuid.entrySet()) {
                if (entry.getValue() > 1) {
                    Tema1.articles.removeIf(element -> element.uuid.equals(entry.getKey()));
                }
            }

            /* Now that articles do not contain duplicates, make englishArticles. */
            for (Article article : Tema1.articles) {
                if (article.language.compareTo("english") == 0) {
                    Tema1.englishArticles.add(article);
                }
            }

            /* Compute statistics. */
            Tema1.nrOfUniqueArticles = Tema1.articles.size();
            Tema1.nrOfDuplicates = Tema1.initialNrOfArticles - Tema1.articles.size();

            /* Write into file. */

        }
    }

    public void topEnglishWord() {
        Tema1.topEnglishWord = Tema1.wordCount.get(0).getKey();
        Tema1.topEnglishWordCount = Tema1.wordCount.get(0).getValue();
    }

    public void writeReports() {
        try {
            FileWriter fw = new FileWriter("reports.txt");

            fw.write("duplicates_found - " + Tema1.nrOfDuplicates + "\n");
            fw.write("unique_articles - " + Tema1.nrOfUniqueArticles + "\n");
            fw.write("best_author - " + Tema1.bestAuthor + " " + Tema1.bestAuthorCount + "\n");
            fw.write("top_language - " + Tema1.topLanguage + " " + Tema1.topLanguageCount + "\n");
            fw.write("top_category - " + normalizeCategoryName(Tema1.topCategory, false) + " " + Tema1.topCategoryCount + "\n");
            fw.write("most_recent_article - " + Tema1.mostRecentArticle.published + " " + Tema1.mostRecentArticle.url + "\n");
            fw.write("top_keyword_en - " + Tema1.topEnglishWord + " " + Tema1.topEnglishWordCount + "\n");

            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void mostRecentArticle(int id) {
        /* Scatter articles. */

        /* Compute indexes. */
        int start = id * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS);
        int end = Math.min(Tema1.articles.size(), (id + 1) * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS));

        /* Iterate through all assigned articles. */
        for (int i = start; i < end; i++) {
            Article article = Tema1.articles.get(i);

            /* If local most recent article doesn't exist yet, just add the article. */
            if (Tema1.mostRecentArticleFromThreads.get(id) == null) {
                Tema1.mostRecentArticleFromThreads.set(id, article);
            }
            else {
                /* If local most recent article is older than current article, save current article. */
                if (Tema1.mostRecentArticleFromThreads.get(id).published.compareTo(article.published) < 0) {
                    Tema1.mostRecentArticleFromThreads.set(id, article);
                } else if (Tema1.mostRecentArticleFromThreads.get(id).published.compareTo(article.published) == 0) {
                    /* TIEBREAKER - uuid (lexicographic order) */
                    if (Tema1.mostRecentArticleFromThreads.get(id).uuid.compareTo(article.uuid) > 0) {
                        Tema1.mostRecentArticleFromThreads.set(id, article);
                    }
                }
            }
        }

        /* Wait for all threads to find local most recent article. */
        try {
            Tema1.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        /* Only thread0 chooses global most recent article. */
        if (id == 0) {
            for (Article article : Tema1.mostRecentArticleFromThreads) {
                /* If there is no most recent article set, just add current article. */
                if (Tema1.mostRecentArticle == null) {
                    Tema1.mostRecentArticle = article;
                } else {
                    /* Keep the more recent article. */
                    if (Tema1.mostRecentArticle.published.compareTo(article.published) < 0) {
                        Tema1.mostRecentArticle = article;
                    }
                    else if (Tema1.mostRecentArticle.published.compareTo(article.published) == 0) {
                        /* TIEBREAKER */
                        if (Tema1.mostRecentArticle.uuid.compareTo(article.uuid) > 0) {
                            Tema1.mostRecentArticle = article;
                        }
                    }
                }
            }
        }
    }

    public void topCategory() {
        for (Map.Entry<String, ArrayList<String>> entry : Tema1.articlesByCategory.entrySet()) {
            if (Tema1.topCategoryCount < entry.getValue().size()) {
                Tema1.topCategory = entry.getKey();
                Tema1.topCategoryCount = entry.getValue().size();
            }
        }
    }

    public void bestAuthor(int id) {
        /* Scatter articles. */

        /* Compute indexes. */
        int start = id * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS);
        int end = Math.min(Tema1.articles.size(), (id + 1) * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS));

        /* Iterate through assigned articles and increment authors' filed in authorFreq. */
        for (int i = start; i < end; i++) {
            String author = Tema1.articles.get(i).author;

            Tema1.partialAuthorFreq.get(id).merge(author, 1, Integer::sum);
        }

        /* Wait for all threads to finish work and then choose the global best author. */
        try {
            Tema1.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        /* Only thread0 searches for global best author. */
        if (id == 0) {
            /* Sum up all partial results. */
            for (int i = 0; i < Tema1.NR_OF_THREADS; i++) {
                for (Map.Entry<String, Integer> entry : Tema1.partialAuthorFreq.get(i).entrySet()) {
                    Tema1.authorFreq.merge(entry.getKey(), entry.getValue(), Integer::sum);

                    if (Tema1.bestAuthorCount < Tema1.authorFreq.get(entry.getKey())) {
                        Tema1.bestAuthor = entry.getKey();
                        Tema1.bestAuthorCount = Tema1.authorFreq.get(entry.getKey());
                    }
                }
            }
        }
    }

    public void topLanguage() {
        /* Iterate through results of articlesByLanguage. */
        for (Map.Entry<String, ArrayList<String>> entry : Tema1.articlesByLanguage.entrySet()) {
            if (Tema1.topLanguageCount < entry.getValue().size()) {
                Tema1.topLanguage = entry.getKey();
                Tema1.topLanguageCount = entry.getValue().size();
            }
        }
    }

    public void writeKeywordsCount() {
        try {
            FileWriter fw = new FileWriter("keywords_count.txt");

            for (Map.Entry<String, Integer> entry : Tema1.wordCount) {
                fw.write(entry.getKey() + " " + entry.getValue() + "\n");
            }

            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeAllArticles() {
        try {
            FileWriter fw = new FileWriter("all_articles.txt");

            /* Order the articles in descending chronological order. */
            Collections.sort(Tema1.articles, new ArticleComparator());

            /* Write the ordered article uuids into the "all_articles.txt" file. */
            for (Article article : Tema1.articles) {
                String line = article.uuid + " " + article.published + "\n";

                fw.write(line);
            }

            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void interestWords(int id) {
        /* Scatter english articles. */

        /* Compute indexes. */
        int start = id * (int) Math.ceil((double) Tema1.englishArticles.size() / Tema1.NR_OF_THREADS);
        int end = Math.min(Tema1.englishArticles.size(), (id + 1) * (int) Math.ceil((double) Tema1.englishArticles.size() / Tema1.NR_OF_THREADS));

        /* Process all assigned articles. */
        for (int i = start; i < end; i++) {
            String text = Tema1.englishArticles.get(i).text.toLowerCase();
            String[] words = text.split("\\s+");
            Set<String> markedWords = new HashSet<>();

            for (String word : words) {
                /* Remove non-letter chars. */
                word = word.replaceAll("[^a-z]", "");

                if (word.isEmpty()) {
                    continue;
                }

                /* This if-clause prevents us from counting the nr of appearances of a word,
                 * instead of the nr of articles in which it appears. */
                if (!markedWords.contains(word) && !Tema1.englishLinkingWords.contains(word)) {
                    /* If word doesn't exist in dictionary, add it with value 1. */
                    /* Else, increment the value. */
                    Tema1.partialWordCount.get(id).merge(word, 1, Integer::sum);

                    markedWords.add(word);
                }
            }
        }

        /* Wait for all threads to finish word-processing before writing into the file. */
        try {
            Tema1.barrier.await();
        } catch(BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        /* Write to file. */
        /* Only thread 0 does the writing. */
        if (id == 0) {
            /* Iterate through all partial results and merge them and create the HashMap. */
            for (int i = 0; i < Tema1.NR_OF_THREADS; i++) {
                for (Map.Entry<String, Integer> entry : Tema1.partialWordCount.get(i).entrySet()) {
                    Tema1.globalWordCount.merge(entry.getKey(), entry.getValue(), Integer::sum);
                }
            }

            for (Map.Entry<String, Integer> entry : Tema1.globalWordCount.entrySet()) {
                Tema1.wordCount.add(entry);
            }

            Tema1.wordCount.sort(new EntryComparator());
        }
    }

    public void merge(ArrayList<Map.Entry<String, Integer>> source, int start, int mid, int end, ArrayList<Map.Entry<String,Integer>> dest, Comparator<Map.Entry<String, Integer>> comp) {
        int i = start;
        int j = mid;
        int k;

        for (k = start; k < end; k++) {
            if (end == j || (i < mid && comp.compare(source.get(i), source.get(j)) < 0)) {
                dest.set(k, source.get(i));
                i++;
            } else {
                dest.set(k, source.get(j));
                j++;
            }
        }
    }

    public void parallelMergeSort(int id, ArrayList<Map.Entry<String, Integer>> array, int N, int P, int initialWidth) {
        /* Compute indexes */
        int start_index = id * (int) Math.ceil((double) array.size() / Tema1.NR_OF_THREADS);
        int end_index = Math.min(array.size(), (id + 1) * (int) Math.ceil((double) array.size() / Tema1.NR_OF_THREADS));

        int start_local = (start_index / initialWidth) * initialWidth;
        int end_local = Math.min(N, (end_index / initialWidth) * initialWidth);

        int width;
        ArrayList<Map.Entry<String, Integer>> arrayCopy = new ArrayList<>(array);

        for (width = 1; width < initialWidth; width = 2 * width) {
            for (int i = start_local; i < end_local; i = i + 2 * width) {
                merge(array, i, i + width, i + 2 * width, arrayCopy, new EntryComparator());
            }

            for (int i = start_local; i < end_local; i = i + 2 * width) {
                array.set(i, arrayCopy.get(i));
            }
        }

        for (width = initialWidth * 2; width <= N; width = width * 2) {
            start_local = (start_index / width) * width;
            end_local = Math.min(N, (end_index / width) * width);

            try {
                Tema1.barrier.await();
            } catch (BrokenBarrierException | InterruptedException e) {
                e.printStackTrace();
            }

            merge(array, start_local, (start_local + end_local) / 2, end_local, arrayCopy, new EntryComparator());

            try {
                Tema1.barrier.await();
            } catch (BrokenBarrierException | InterruptedException e) {
                e.printStackTrace();
            }

            if (id == 0) {
                for (int i = 0; i < N; i++) {
                    array.set(i, arrayCopy.get(i));
                }
            }
        }
    }

    public void languageClassification(int id) {
        /* Compute indexes. */
        int start = id * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS);
        int end = Math.min(Tema1.articles.size(), (id + 1) * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS));

        /* Iterate through assigned articles. */
        for (int i = start; i < end; i++) {
            Article currentArticle = Tema1.articles.get(i);

            if (Tema1.languages.contains(currentArticle.language)) {
                Tema1.partialArticlesByLanguage.get(id).compute(currentArticle.language, (lang, list) -> {
                    if (list == null) {
                        list = new ArrayList<>();
                    }
                    if (!list.contains(currentArticle.uuid)) {
                        list.add(currentArticle.uuid);
                    }
                    return list;
                });
            }
        }

        /* Wait for all threads to finish execution before centralizing results into files. */
        try {
            Tema1.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        if (id == 0) {
            /* Merge all partial results into global results. */
            for (int i = 0; i < Tema1.NR_OF_THREADS; i++) {
                for (Map.Entry<String, ArrayList<String>> entry : Tema1.partialArticlesByLanguage.get(i).entrySet()) {
                    Tema1.articlesByLanguage.compute(entry.getKey(), (language, list) ->
                    {list.addAll(entry.getValue());
                        return list;});
                }
            }
        }

        /* Wait for merge to be done by thread 0. */
        try {
            Tema1.barrier.await();
        } catch(BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        /* Scatter languages. */
        start = id * (int) Math.ceil((double) Tema1.languages.size() / Tema1.NR_OF_THREADS);
        end = Math.min(Tema1.languages.size(), (id + 1) * (int) Math.ceil((double) Tema1.languages.size() / Tema1.NR_OF_THREADS));

        /* Write into files. */
        for (int i = start; i < end; i++) {
            String language = Tema1.languages.get(i);

            ArrayList<String> languageResults = Tema1.articlesByLanguage.get(language);

            if (!languageResults.isEmpty()) {
                /* Order the articles inside languages. */
                Collections.sort(languageResults);

                try {
                    FileWriter fw = new FileWriter(language + ".txt");

                    for (String uuid : languageResults) {
                        fw.write(uuid + "\n");
                    }

                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void categoryClassification(int id) {
        /* Compute indexes. */
        int start = id * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS);
        int end = Math.min(Tema1.articles.size(), (id + 1) * (int) Math.ceil((double) Tema1.articles.size() / Tema1.NR_OF_THREADS));

        /* Iterate through the assigned section of articles. */
        for (int i = start; i < end; i++) {
            /* Iterate through article's categories. */
            Article currentArticle = Tema1.articles.get(i);

            for (String category : currentArticle.categories) {
                if (Tema1.categories.contains(category)) {
                    Tema1.partialArticlesByCategory.get(id).compute(category, (cat, list) -> {
                        if (list == null) {
                            list = new ArrayList<>();
                        }
                        if (!list.contains(currentArticle.uuid)) {
                            list.add(currentArticle.uuid);
                        }
                        return list;
                    });
                }
            }
        }

        /* Wait for all threads to finish execution before centralizing results into files. */
        try {
            Tema1.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        if (id == 0) {
            /* Merge all partial results. */
            for (int i = 0; i < Tema1.NR_OF_THREADS; i++) {
                for (Map.Entry<String, ArrayList<String>> entry : Tema1.partialArticlesByCategory.get(i).entrySet()) {
                    Tema1.articlesByCategory.compute(entry.getKey(), (language, list) ->
                    {list.addAll(entry.getValue());
                        return list;});
                }
            }
        }

        /* Wait for merge by thread 0 to be done. */
        try {
            Tema1.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }

        start = id * (int) Math.ceil((double) Tema1.categories.size() / Tema1.NR_OF_THREADS);
        end = Math.min(Tema1.categories.size(), (id + 1) * (int) Math.ceil((double) Tema1.categories.size() / Tema1.NR_OF_THREADS));

        for (int i = start; i < end; i++) {
            String category = Tema1.categories.get(i);

            ArrayList<String> categoryResults = Tema1.articlesByCategory.get(category);

            if (categoryResults != null && !categoryResults.isEmpty()) {
                /* Keep lexicographic order. */
                Collections.sort(categoryResults);

                try {
                    FileWriter fw = new FileWriter(normalizeCategoryName(category, true));

                    for (String uuid : categoryResults) {
                        fw.write(uuid + "\n");
                    }

                    fw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public String normalizeCategoryName(String category, boolean isFile) {
        StringBuffer fileName = new StringBuffer();

        for (char c : category.toCharArray()) {
            /* If char is a coma, step over it. */
            if (c == ',') {
                continue;
            }
            /*If char is blank space, replace it with '_'.  */
            else if (c == ' ') {
                fileName.append('_');
            } else {
                fileName.append(c);
            }
        }

        if (isFile) {
            fileName.append(".txt");
        }

        return fileName.toString();
    }
}
