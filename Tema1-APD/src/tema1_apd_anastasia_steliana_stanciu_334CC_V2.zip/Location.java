public class Location {
    public String name;
    public String sentiment;
}
