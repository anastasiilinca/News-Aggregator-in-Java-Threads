public class Person{
    public String name;
    public String sentiment;
}
