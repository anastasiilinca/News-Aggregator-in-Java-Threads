public class Entity {
    public Person[] persons;
    public Organization[] organizations;
    public Location[] locations;
}
