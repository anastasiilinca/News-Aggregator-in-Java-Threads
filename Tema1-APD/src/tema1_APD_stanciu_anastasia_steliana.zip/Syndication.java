public class Syndication {
    public Boolean syndicated;
    public String syndicate_id;
    public Boolean first_syndicated;
}
