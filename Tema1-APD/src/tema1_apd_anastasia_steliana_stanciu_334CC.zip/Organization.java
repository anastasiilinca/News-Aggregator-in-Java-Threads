public class Organization{
    public String name;
    public String sentiment;
    public Ticker[] tickers;
}
