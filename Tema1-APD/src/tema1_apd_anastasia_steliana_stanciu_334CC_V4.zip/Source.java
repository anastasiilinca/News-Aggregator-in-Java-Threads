public class Source {
    public String type;
    public String[] city;
    public String[] state;
    public String[] country;
    public String domain_type;
    public String agency;
    public String organization_name;
}
