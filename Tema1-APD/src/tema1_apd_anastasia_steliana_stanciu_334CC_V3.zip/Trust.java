public class Trust {
    public String[] categories;
    public String[] top_news;
    public String bias;
    public Source source;
}
