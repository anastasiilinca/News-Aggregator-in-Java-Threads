public class Ticker {
    public String ticker;
    public String exchange;
}
